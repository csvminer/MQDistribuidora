# SISTEMA INTELIGENTE DE PREDICCIÓN DE INVENTARIOS CON BIG DATA PARA EL MERCADO DE CONSTRUCCIÓN

Proyecto Final de las materias de Base de Datos, Aprendizaje de Maquina, Minería de Datos de segundo ciclo.

## Mas información:

- v2.0.0 en desarrollo.
- Licencia MIT.
