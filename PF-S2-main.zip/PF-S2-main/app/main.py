from vistas.principal import generar_ventana_principal


def main():
    generar_ventana_principal()


main()